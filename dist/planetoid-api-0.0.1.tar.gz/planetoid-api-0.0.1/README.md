# PlanetoidAPI

 Planetoid's API official library to access free APIs.