def first_fn(number):
    print("This is first function")
    return number
